# NEON PLAYER X — Real External Economy Pipeline

This extension preserves the existing economic engine, ledger and provider adapters and adds a governed production path:

`discover external work → reality attestation → net profitability → NEON_ORB authorization → authorized provider execution → independent settlement verification → real-asset registry → currency conversion`

## Reality gate

An opportunity is executable only when an allowlisted HTTPS verification endpoint returns:

- `verified: true`
- matching `opportunityId`
- `workRef`
- `deliverableRef`
- `settlementProvider`

Unverified opportunities may remain visible for audit/discovery, but cannot pass the governor.

## Profitability gate

The opportunity engine computes:

`netProfitEUR = revenueEUR - spendEUR - providerFeesEUR - networkCostEUR - otherCostEUR`

and `marginBps`. NEON_ORB applies minimum profit, minimum margin and daily/single-spend limits.

## Provider gate

Execution no longer trusts an `executeUrl` supplied by an opportunity. The provider identity must be configured through:

`NEON_AUTHORIZED_EXECUTION_PROVIDERS='{"provider-id":"https://authorized.example/execute"}'`

The destination is also checked against `NEON_ALLOWED_PROVIDER_HOSTS` and must use HTTPS.

## Settlement and real-asset gate

An HTTP 2xx execution response is only a submission. It is not revenue.

A settlement enters the computable economy only when:

1. the provider reference is present;
2. the settlement is explicitly verified;
3. NEON_ORB accepts the amount and daily limit;
4. `workRef` and `deliverableRef` are present;
5. the real-economic registry stores the resulting verified asset.

Pending, unverified or unverifiable values never change the computable asset registry.

## Currency converter

`server/currency-converter.js` adds a currency-pair conversion layer with rate, fees, network cost, slippage, quote reference and expiry. Conversion execution remains governed and does not itself turn an unverified external balance into a real asset.

## Default safety posture

The existing defaults remain conservative:

- `READ_VERIFY_ONLY`
- spending disabled
- signing disabled
- withdrawals disabled
- production mutation endpoints require `NEON_ADMIN_TOKEN`
- provider destinations are allowlisted
- no private keys are stored in the economic registry

The existing internal ledger and modules are retained; the new registry is additive.
